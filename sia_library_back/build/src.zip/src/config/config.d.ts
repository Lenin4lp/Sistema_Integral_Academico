export declare const TOKEN_SECRET = "secret123";
export declare const REFRESH_TOKEN_SECRET = "secret123";
