export declare function createAccesToken(payload: object): Promise<unknown>;
