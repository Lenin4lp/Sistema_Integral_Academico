"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TOKEN_SECRET = void 0;
exports.TOKEN_SECRET = "secret123";
