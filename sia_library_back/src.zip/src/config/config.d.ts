export declare const TOKEN_SECRET = "secret123";
